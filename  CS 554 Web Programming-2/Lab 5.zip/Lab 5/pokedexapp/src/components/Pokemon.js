import React, { useState, useEffect } from "react";
import axios from "axios";
import noImage from "../img/no-image-available.jpg";
import "../App.css";

const Pokemon = (props) => {
  const [pokeData, setpokeData] = useState(undefined);
  useEffect(() => {
    async function fetchData() {
      try {
        const { data: poke } = await axios.get(
          `https://pokeapi.co/api/v2/pokemon/${props.match.params.id}`
        );
        setpokeData(poke);
      } catch (e) {
        console.log(e);
      }
    }
    fetchData();
  }, [props.match.params.id]);

  let img = null;
  if (pokeData && pokeData.sprites.front_shiny) {
    img = (
      <img
        className="img-pattern"
        alt="Pokemon"
        src={pokeData.sprites.front_shiny}
      />
    );
  } else {
    img = <img className="img-pattern" alt="Pokemon" src={noImage} />;
  }

  return (
    <div className="Poke-body">
      <h1 className="cap-first-letter">{pokeData && pokeData.name}</h1>
      {pokeData && img}
      <br />
      {pokeData ? null : (
        <h2>
          ERROR 404: NO MORE POKEMON DATA AVAILABLE! PLEASE FIND MORE POKEMON.
        </h2>
      )}
      <p>
        {pokeData ? <span>ID: </span> : null}
        {pokeData && pokeData.id}
        <br />
        {pokeData ? <span>Base-experience: </span> : null}
        {pokeData && pokeData.base_experience}
        <br />
        {pokeData ? <span>Height: </span> : null} {pokeData && pokeData.height}
        <br />
        {pokeData ? <span>Weight: </span> : null} {pokeData && pokeData.weight}
        <br />
      </p>
      {pokeData ? <span className="title">Abilities: </span> : null}
      <dl className="list-unstyled">
        {pokeData &&
          pokeData.abilities.map((ability) => {
            return <dt key={ability.ability.name}>{ability.ability.name}</dt>;
          })}
      </dl>
      {pokeData ? <span className="title">Moves: </span> : null}
      <dl className="list-unstyled">
        {pokeData &&
          pokeData.moves.map((m) => {
            return <dt key={m.move.name}>{m.move.name}</dt>;
          })}
      </dl>
      {pokeData ? <span className="title">Types: </span> : null}
      <dl className="list-unstyled">
        {pokeData &&
          pokeData.types.map((t) => {
            return <dt key={t.type.name}>{t.type.name}</dt>;
          })}
      </dl>
    </div>
  );
};
export default Pokemon;
