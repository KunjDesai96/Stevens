import React, { useState, useEffect } from "react";
import axios from "axios";
import "../App.css";

const Berry = (props) => {
  const [machineData, setmachineData] = useState(undefined);
  useEffect(() => {
    async function fetchData() {
      try {
        const { data: machine } = await axios.get(
          `https://pokeapi.co/api/v2/machine/${props.match.params.id}`
        );
        setmachineData(machine);
      } catch (e) {
        console.log(e);
      }
    }
    fetchData();
  }, [props.match.params.id]);

  return (
    <div className="machine-body">
      {machineData ? (
        <h1 className="cap-first-letter">Machine ID: {machineData.id}</h1>
      ) : null}
      {machineData ? null : (
        <h2>
          ERROR 404: NO MORE MACHINES DATA AVAILABLE! PLEASE FIND MORE MACHINES.
        </h2>
      )}
      <p>
        {machineData ? <span>ID: </span> : null}
        {machineData && machineData.id}
        <br />
        {machineData ? <span>Item Name: </span> : null}
        {machineData && machineData.item.name}
        <br />
        {machineData ? <span>Move Name: </span> : null}
        {machineData && machineData.move.name}
        <br />
        {machineData ? <span>Version Group Name: </span> : null}
        {machineData && machineData.version_group.name}
        <br />
      </p>
    </div>
  );
};
export default Berry;
