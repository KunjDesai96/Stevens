import React from "react";
export default function PageNotFound() {
  return (
    <div>
      <h1>ERROR 404: PAGE NOT FOUND.</h1>
    </div>
  );
}
