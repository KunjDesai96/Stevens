import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "../App.css";

const PokemonList = (props) => {
  let currentPageNumber = parseInt(props.match.params.page);
  const [pokemonData, setPokemonData] = useState([]);
  const [currentPageURL, setCurrentPageURL] = useState();
  const [nextPageURL, setNextPageURL] = useState();
  const [prevPageURL, setPrevPageURL] = useState();
  let li = null;

  let nextLink = `/pokemon/page/${currentPageNumber + 1}`;
  let previousLink = `/pokemon/page/${currentPageNumber - 1}`;
  function gotoNextPage() {
    setCurrentPageURL(nextPageURL);
  }

  function gotoPrevPage() {
    setCurrentPageURL(prevPageURL);
    currentPageNumber = currentPageNumber - 1;
  }

  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(
          "https://pokeapi.co/api/v2/pokemon/?offset=" +
            currentPageNumber * 20 +
            "&limit=20"
        );
        setPokemonData(data.results.map((p) => p));
        setNextPageURL(data.next);
        setPrevPageURL(data.previous);
      } catch (e) {
        return (
          <div>
            <h1> Pokemon Not Found</h1>
          </div>
        );
      }
    }
    fetchData();
  }, [currentPageNumber]);

  const buildListItem = (p) => {
    var url = p.url;
    var array = url.split("/");
    var id = array[array.length - 2];
    return (
      <li key={p.name}>
        <Link to={`/pokemon/${id}`}>
          {p.name.charAt(0).toUpperCase() + p.name.slice(1)}
        </Link>
      </li>
    );
  };

  li =
    pokemonData &&
    pokemonData.map((p) => {
      return buildListItem(p);
    });

  return (
    <div className="App-body">
      <h1>Pokémon</h1>
      {pokemonData.length !== 0 && prevPageURL ? (
        <Link
          className="showlink"
          to={previousLink}
          onClick={() => gotoPrevPage()}
        >
          Previous
        </Link>
      ) : null}
      {pokemonData.length !== 0 && nextPageURL ? (
        <Link className="showlink" to={nextLink} onClick={() => gotoNextPage()}>
          Next
        </Link>
      ) : null}
      <ul className="li">{li}</ul>
      {pokemonData.length !== 0 ? null : (
        <h2>ERROR 404: NO MORE POKEMON PAGES AVAILABLE</h2>
      )}
    </div>
  );
};

export default PokemonList;
