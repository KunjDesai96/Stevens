import React, { useState, useEffect } from "react";
import axios from "axios";
import "../App.css";

const Berry = (props) => {
  const [berryData, setberryData] = useState(undefined);
  useEffect(() => {
    async function fetchData() {
      try {
        const { data: berry } = await axios.get(
          `https://pokeapi.co/api/v2/berry/${props.match.params.id}`
        );
        setberryData(berry);
      } catch (e) {
        console.log(e);
      }
    }
    fetchData();
  }, [props.match.params.id]);

  return (
    <div className="berry-body">
      <h1 className="cap-first-letter">{berryData && berryData.name}</h1>
      {berryData ? null : (
        <h2>
          ERROR 404: NO MORE BERRY DATA AVAILABLE! PLEASE FIND MORE BERRIES.
        </h2>
      )}
      <p>
        {berryData ? <span>ID: </span> : null}
        {berryData && berryData.id}
        <br />
        {berryData ? <span>Max Harvest: </span> : null}
        {berryData && berryData.max_harvest}
        <br />
        {berryData ? <span>Natural Gift Power: </span> : null}{" "}
        {berryData && berryData.natural_gift_power}
        <br />
        {berryData ? <span>Size: </span> : null} {berryData && berryData.size}
        <br />
        {berryData ? <span>Smoothness: </span> : null}{" "}
        {berryData && berryData.smoothness}
        <br />
        {berryData ? <span>Soil Dryness: </span> : null}{" "}
        {berryData && berryData.soil_dryness}
        <br />
        {berryData ? <span>Firmness: </span> : null}{" "}
        {berryData && berryData.firmness.name}
        <br />
        {berryData ? <span>Items: </span> : null}{" "}
        {berryData && berryData.item.name}
        <br />
        {berryData ? <span>Natural Gift Type: </span> : null}
        {berryData && berryData.natural_gift_type.name}
        <br />
      </p>
      {berryData ? <span className="title">Flavors</span> : null}
      <dl className="list-unstyled">
        {berryData &&
          berryData.flavors.map((t) => {
            return (
              <dt key={t.flavor.name}>
                Flavor: {t.flavor.name} - Potency: {t.potency}
              </dt>
            );
          })}
      </dl>
    </div>
  );
};
export default Berry;
