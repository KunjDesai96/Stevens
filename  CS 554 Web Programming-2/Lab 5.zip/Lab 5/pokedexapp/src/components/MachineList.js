import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "../App.css";

const BerryList = (props) => {
  let currentPageNumber = parseInt(props.match.params.page);
  const [machineData, setmachineData] = useState([]);
  const [currentPageURL, setCurrentPageURL] = useState();
  const [nextPageURL, setNextPageURL] = useState();
  const [prevPageURL, setPrevPageURL] = useState();
  let li = null;

  let nextLink = `/machines/page/${currentPageNumber + 1}`;
  let previousLink = `/machines/page/${currentPageNumber - 1}`;
  function gotoNextPage() {
    setCurrentPageURL(nextPageURL);
  }

  function gotoPrevPage() {
    setCurrentPageURL(prevPageURL);
    currentPageNumber = currentPageNumber - 1;
  }

  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(
          "https://pokeapi.co/api/v2/machine/?offset=" +
            currentPageNumber * 20 +
            "&limit=20"
        );
        setmachineData(data.results.map((p) => p));
        setNextPageURL(data.next);
        setPrevPageURL(data.previous);
      } catch (e) {
        console.log(e);
      }
    }
    fetchData();
  }, [currentPageNumber]);

  const buildListItem = (p) => {
    var url = p.url;
    var array = url.split("/");
    var id = array[array.length - 2];
    return (
      <li key={p.url}>
        <Link to={`/machines/${id}`}>{id}</Link>
      </li>
    );
  };

  li =
    machineData &&
    machineData.map((p) => {
      return buildListItem(p);
    });

  return (
    <div className="App-body">
      <h1>Machines</h1>
      {machineData.length !== 0 && prevPageURL ? (
        <Link
          className="showlink"
          to={previousLink}
          onClick={() => gotoPrevPage()}
        >
          Previous
        </Link>
      ) : null}
      {machineData.length !== 0 && nextPageURL ? (
        <Link className="showlink" to={nextLink} onClick={() => gotoNextPage()}>
          Next
        </Link>
      ) : null}
      <ul className="li">{li}</ul>
      {machineData.length !== 0 ? null : (
        <h2>ERROR 404: NO MORE MACHINE PAGES AVAILABLE</h2>
      )}
    </div>
  );
};

export default BerryList;
