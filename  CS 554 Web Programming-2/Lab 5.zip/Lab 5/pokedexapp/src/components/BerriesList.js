import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

import "../App.css";

const BerriesList = (props) => {
  let currentPageNumber = parseInt(props.match.params.page);
  const [berryData, setberryData] = useState([]);
  const [currentPageURL, setCurrentPageURL] = useState();
  const [nextPageURL, setNextPageURL] = useState();
  const [prevPageURL, setPrevPageURL] = useState();
  let li = null;

  let nextLink = `/berries/page/${currentPageNumber + 1}`;
  let previousLink = `/berries/page/${currentPageNumber - 1}`;
  function gotoNextPage() {
    setCurrentPageURL(nextPageURL);
  }

  function gotoPrevPage() {
    setCurrentPageURL(prevPageURL);
    currentPageNumber = currentPageNumber - 1;
  }

  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(
          "https://pokeapi.co/api/v2/berry/?offset=" +
            currentPageNumber * 20 +
            "&limit=20"
        );
        setberryData(data.results.map((p) => p));
        setNextPageURL(data.next);
        setPrevPageURL(data.previous);
      } catch (e) {
        console.log(e);
      }
    }
    fetchData();
  }, [currentPageNumber]);

  const buildListItem = (p) => {
    var url = p.url;
    var array = url.split("/");
    var id = array[array.length - 2];
    return (
      <li key={p.name}>
        <Link to={`/berries/${id}`}>
          {p.name.charAt(0).toUpperCase() + p.name.slice(1)}
        </Link>
      </li>
    );
  };

  li =
    berryData &&
    berryData.map((p) => {
      return buildListItem(p);
    });

  return (
    <div className="App-body">
      <h1>Berries</h1>
      {berryData.length !== 0 && prevPageURL ? (
        <Link
          className="showlink"
          to={previousLink}
          onClick={() => gotoPrevPage()}
        >
          Previous
        </Link>
      ) : null}
      {berryData.length !== 0 && nextPageURL ? (
        <Link className="showlink" to={nextLink} onClick={() => gotoNextPage()}>
          Next
        </Link>
      ) : null}
      <ul className="li">{li}</ul>
      {berryData.length !== 0 ? null : (
        <h2>ERROR 404: NO MORE BERRY PAGES AVAILABLE</h2>
      )}
    </div>
  );
};

export default BerriesList;
