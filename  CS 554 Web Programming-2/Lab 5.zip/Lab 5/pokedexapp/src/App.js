import React from "react";
import logo from "./img/header-logo.gif";
import { Switch, BrowserRouter as Router, Route, Link } from "react-router-dom";
import PokemonList from "./components/PokemonList";
import BerriesList from "./components/BerriesList";
import MachineList from "./components/MachineList";
import Pokemon from "./components/Pokemon";
import Berries from "./components/Berries";
import Machines from "./components/Machines";

import "./App.css";
import PageNotFound from "./components/PageNotFound";

export default function MainPage() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to the Pokédex</h1>
        </header>
        <br />
        <br />
        <div className="App-body">
          <h2>Information about Pokémon, Berries and Machine</h2>
          <p>
            This website will give you some basic information about Pokémon,
            <br />
            Berries and Machine. You can search any of them by their id and page
            <br />
            number appending them in the given URL.
          </p>
          <Link className="showlink" to="/pokemon/page/0">
            Pokémon
          </Link>
          <Link className="showlink" to="/berries/page/0">
            Berries
          </Link>
          <Link className="showlink" to="/machines/page/0">
            Machines
          </Link>
          <Switch>
            <Route exact path="/" />
            <Route exact path="/pokemon/page/:page" component={PokemonList} />
            <Route exact path="/berries/page/:page" component={BerriesList} />
            <Route exact path="/machines/page/:page" component={MachineList} />
            <Route exact path="/pokemon/:id" component={Pokemon} />
            <Route exact path="/berries/:id" component={Berries} />
            <Route exact path="/machines/:id" component={Machines} />
            <Route path="*" status={404}>
              <PageNotFound />
            </Route>
          </Switch>
        </div>
      </div>
    </Router>
  );
}
