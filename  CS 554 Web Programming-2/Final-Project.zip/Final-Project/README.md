### Well Being - Track your life

## 554 Project 

`redis-server`
`node server.js`
`npm start`
