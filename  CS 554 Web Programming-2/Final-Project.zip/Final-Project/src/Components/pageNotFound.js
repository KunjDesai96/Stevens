import React from 'react';


const Error404 = () => {
	
        return (
            <div className='show-body'>
                Error 404 - Page Not found
            </div>
        );
    

};

export default Error404;
