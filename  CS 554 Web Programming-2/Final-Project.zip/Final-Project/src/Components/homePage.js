import React from 'react';


const Home = () => {
	
        return (
            <div className='App-font-solid'>
                <p>Welcome to Food App!</p>
                We have our deadline in almost a month!
            </div>
        );
    

};

export default Home;
