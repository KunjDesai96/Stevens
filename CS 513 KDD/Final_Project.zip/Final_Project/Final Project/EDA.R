rm(list=ls())

library(randomForest)
library(plyr)   #Map value function
library(rpart)        #Decision Tree-2
library(rpart.plot)   #Decision Tree
library(rattle)       #Decision Tree
library("C50")        #CS0          -3
library(RColorBrewer) #Decision Tree
library(e1071)        #Naivye Bayes -4
library(kknn)         #kknn         -5
library("neuralnet")  #neuralnet    -6
library(caret)        #Logistic Regression


dev.off()
# load data into memory
dataSet<- read.csv(file.choose())
View(dataSet)


#To factor the data set
dataSet[dataSet==""]<-NA
is.na(dataSet) <- sapply(dataSet, is.infinite)  #setting infinite value to NA
dataSet[is.na(dataSet)] <- 0 #setting NA value to 0
dataSet$REFERRAL_SOURCE <- as.character(dataSet$REFERRAL_SOURCE)     # to change na values in character array
dataSet$REFERRAL_SOURCE[is.na(dataSet$REFERRAL_SOURCE)] <- "Single"  # to change na values in character array
sum(is.na(dataSet))  # to check for na values
dataSet<-na.omit(dataSet)
sum(is.na(dataSet))  # to check for na values
sum(is.nan(factor(dataSet))) # to check for nan values 
sum(is.infinite(factor(dataSet)))  #to check for infinite values


#Converting everything to factor
dataSet$REHIRE <- as.character(dataSet$REHIRE)
dataSet$REHIRE <- as.factor(dataSet$REHIRE)
dataSet$IS_FIRST_JOB <- as.character(dataSet$IS_FIRST_JOB)
dataSet$IS_FIRST_JOB <- as.factor(dataSet$IS_FIRST_JOB)
dataSet$STATUS <- as.character(dataSet$STATUS)
dataSet$STATUS <- as.factor(dataSet$STATUS)
dataSet$ETHNICITY <- as.character(dataSet$ETHNICITY)
dataSet$ETHNICITY <- as.factor(dataSet$ETHNICITY)
dataSet$EDUCATION_LEVEL <- as.character(dataSet$EDUCATION_LEVEL)
dataSet$EDUCATION_LEVEL <- as.factor(dataSet$EDUCATION_LEVEL)
dataSet$SEX <- as.character(dataSet$SEX)
dataSet$SEX <- as.factor(dataSet$SEX)
dataSet$MARITAL_STATUS <- as.character(dataSet$MARITAL_STATUS)
dataSet$MARITAL_STATUS <- as.factor(dataSet$MARITAL_STATUS)
#Decreasing no of levels
dataSet$HRLY_RATE<-findInterval(dataSet$HRLY_RATE, c(30, 60, 90))
dataSet$HRLY_RATE <- as.factor(dataSet$HRLY_RATE)
dataSet$AGE<-findInterval(dataSet$AGE, c(20, 30, 40))
dataSet$AGE <- as.factor(dataSet$AGE)
dataSet$JOB_SATISFACTION <- as.factor(dataSet$JOB_SATISFACTION)
dataSet$TERMINATION_YEAR<-findInterval(dataSet$TERMINATION_YEAR, c(2008, 2011, 2017))
dataSet$TERMINATION_YEAR <- as.factor(dataSet$TERMINATION_YEAR)
dataSet$PREVYR_1 <- as.factor(dataSet$PREVYR_1)
dataSet$NUMBER_OF_TEAM_CHANGED<-findInterval(dataSet$NUMBER_OF_TEAM_CHANGED, c(0, 1, 2))
dataSet$NUMBER_OF_TEAM_CHANGED <- as.factor(dataSet$NUMBER_OF_TEAM_CHANGED)
dataSet$PREVYR_2 <- as.factor(dataSet$PREVYR_2)
dataSet$PREVYR_3 <- as.factor(dataSet$PREVYR_3)
dataSet$PREVYR_4 <- as.factor(dataSet$PREVYR_4)
dataSet$PREVYR_5 <- as.factor(dataSet$PREVYR_5)

##########Performing EDA########################

install.packages("grid")
install.packages("gridExtra")
library(gridExtra)
library(grid)

grid.table(t(summary(dataSet)))



install.packages("corrplot")
library(corrplot)
library(plyr)
numeric.var <- sapply(dataSet, is.numeric)
corr.matrix <- cor(dataSet[,numeric.var])
corrplot::corrplot(corr.matrix, main="\n\nCorrelation Plot for Numerical Variables", method="number")





num.col <- sapply(dataSet,is.numeric)
numeric_data <- dataSet[,num.col]
str(numeric_data)

library(corrplot)
cor.data <- cor(numeric_data) # , is used in order to get all numeric coloumns 
print(cor.data)
print(corrplot(cor.data, method = 'color'))


# Removing Customer ID,JOBCODE,REFERAL_SOURCE,JOB_GROUP column
dataSet <- subset(dataSet, select = -c(1,4,11,22))
# Removing ANNUAL_RATE column as ANNUAL_RATE and HRLY_RATE column are co-related
#remove highly correlated variables
dataSet <- subset(dataSet, select = -c(1))
#CompanyData$StreamingMovies <- NULL



# Barchart for Churn vs Not churn (Gender)
library(ggplot2)
ggplot(dataSet) + geom_bar(aes(x = SEX, fill = STATUS), position="dodge") +
  scale_fill_manual(values=c("#3777AF", "#F08536"))



install.packages("ggpubr")
library(ggpubr)

summary(dataSet)
################### For SEX STATUS  ###############################
male_yes <- sum(dataSet$SEX == 'M' & dataSet$STATUS  == "A")
female_yes <- sum(dataSet$SEX == 'F' & dataSet$STATUS == "A")

male_no <- sum(dataSet$SEX  == 'M' & dataSet$STATUS  == "T")
female_no <- sum(dataSet$SEX  == 'F' & dataSet$STATUS  == "T")


data <- data.frame(
  category=c("Male(Yes Sex)", "Female(Yes Sex)"),
  count=c(male_yes, female_yes)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_text( x=3.23, aes(y=labelPosition, label=label), size=6) +
  scale_fill_brewer(palette=8) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")

##################
data <- data.frame(
  category=c("Male(No SEX)", "Female(No SEX)"),
  count=c(male_no, female_no)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=6) +
  scale_fill_brewer(palette=8) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")



# ##########################################################

dataSet$ANNUAL_RATE<-findInterval(dataSet$ANNUAL_RATE, c(20000,40000, 80000, 100000))
dataSet$ANNUAL_RATE <- as.factor(dataSet$ANNUAL_RATE)
# ################ For ANNUAL STATUS  ###############################
hr_yes_0 <- sum(dataSet$ANNUAL_RATE == 1 & dataSet$STATUS  == "A")
hr_yes_1 <- sum(dataSet$ANNUAL_RATE  == 2 & dataSet$STATUS  == "A")
hr_yes_2 <- sum(dataSet$ANNUAL_RATE  == 3 & dataSet$STATUS  == "A")
hr_yes_3 <- sum(dataSet$ANNUAL_RATE  == 4 & dataSet$STATUS  == "A")

hr_no_0 <- sum(dataSet$ANNUAL_RATE  == 1 & dataSet$STATUS  == "T")
hr_no_1 <- sum(dataSet$ANNUAL_RATE  == 2 & dataSet$STATUS == "T")
hr_no_2 <- sum(dataSet$ANNUAL_RATE  == 3 & dataSet$STATUS == "T")
hr_no_3 <- sum(dataSet$ANNUAL_RATE  == 4 & dataSet$STATUS == "T")


data <- data.frame(
  category=c("ANNUAL_RATE_(20-40k) (A)", "ANNUAL_RATE(40-80k)(A)","ANNUAL_RATE(80-100k)(A)","ANNUAL_RATE(100k>)(A)"),
  count=c(hr_yes_0, hr_yes_1,hr_yes_2,hr_yes_3)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
##################
data <- data.frame(
  category=c("ANNUAL_RATE_(20-40k) (T)", "ANNUAL_RATE(40-80k)(T)","ANNUAL_RATE(80-100k)(T)","ANNUAL_RATE(100k>)(T)"),
  count=c(hr_no_0,hr_no_1,hr_no_2,hr_no_3)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")


# ##########################################################
dataSet$AGE<-findInterval(dataSet$AGE, c(20, 30, 40))
dataSet$AGE <- as.factor(dataSet$AGE)
# ################ For AGE STATUS  ###############################


a_yes_0 <- sum(dataSet$AGE == 1 & dataSet$STATUS  == "A")
a_yes_1 <- sum(dataSet$AGE  == 2 & dataSet$STATUS  == "A")
a_yes_2 <- sum(dataSet$AGE  == 3 & dataSet$STATUS  == "A")
a_yes_3 <- sum(dataSet$AGE  == 4 & dataSet$STATUS  == "A")

a_no_0 <- sum(dataSet$AGE  == 1 & dataSet$STATUS  == "T")
a_no_1 <- sum(dataSet$AGE  == 2 & dataSet$STATUS == "T")
a_no_2 <- sum(dataSet$AGE  == 3 & dataSet$STATUS == "T")
a_no_3 <- sum(dataSet$AGE  == 4 & dataSet$STATUS == "T")


data <- data.frame(
  category=c("AGE_0 (A)", "AGE_1(A)","AGE_2(A)","AGE_3(A)"),
  count=c(a_yes_0, a_yes_1,a_yes_2,a_yes_3)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
##################
data <- data.frame(
  category=c("AGE_0 (T)", "AGE_1(T)","AGE_2(T)","AGE_3(T)"),
  count=c(a_no_0,a_no_1,a_no_2,a_no_3)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
# ##########################################################


# ################ For Termination year STATUS  ###############################
dataSet$TERMINATION_YEAR<-findInterval(dataSet$TERMINATION_YEAR, c(0,2005, 2011, 2014,2016))
dataSet$TERMINATION_YEAR <- as.factor(dataSet$TERMINATION_YEAR)
# ##########################################################
ty_yes_4 <- sum(dataSet$TERMINATION_YEAR == 1 & dataSet$STATUS  == "A")
ty_yes_0 <- sum(dataSet$TERMINATION_YEAR == 2 & dataSet$STATUS  == "A")
ty_yes_1 <- sum(dataSet$TERMINATION_YEAR  == 3 & dataSet$STATUS  == "A")
ty_yes_2 <- sum(dataSet$TERMINATION_YEAR  == 4 & dataSet$STATUS  == "A")
ty_yes_3 <- sum(dataSet$TERMINATION_YEAR  == 5 & dataSet$STATUS  == "A")

ty_no_4 <- sum(dataSet$TERMINATION_YEAR == 1 & dataSet$STATUS  == "T")
ty_no_0 <- sum(dataSet$TERMINATION_YEAR  == 2 & dataSet$STATUS  == "T")
ty_no_1 <- sum(dataSet$TERMINATION_YEAR  == 3 & dataSet$STATUS == "T")
ty_no_2 <- sum(dataSet$TERMINATION_YEAR  == 4 & dataSet$STATUS == "T")
ty_no_3 <- sum(dataSet$TERMINATION_YEAR  == 5 & dataSet$STATUS == "T")


data <- data.frame(
  category=c("Not Terminated(A)","2005-2011 (A)", "2011-2014(A)","2014-2016(A)","2016>(A)"),
  count=c(ty_yes_4,ty_yes_0, ty_yes_1,ty_yes_2,ty_yes_3)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))

data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
##################
data <- data.frame(
  category=c("2005-2011 (T)", "2011-2014(T)","2014-2016(T)","2016>(T)"),
  count=c(ty_no_0,ty_no_1,ty_no_2,ty_no_3)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")


# ################ For MARITIAL STATUS  ###############################
# ##########################################################
M_yes_0 <- sum(dataSet$MARITAL_STATUS == 'Married' & dataSet$STATUS  == "A")
M_yes_1 <- sum(dataSet$MARITAL_STATUS  == 'Single' & dataSet$STATUS  == "A")
M_yes_2 <- sum(dataSet$MARITAL_STATUS  == 'Divoced' & dataSet$STATUS  == "A")

M_no_0 <- sum(dataSet$MARITAL_STATUS  == 'Married' & dataSet$STATUS  == "T")
M_no_1 <- sum(dataSet$MARITAL_STATUS  == 'Single' & dataSet$STATUS == "T")
M_no_2 <- sum(dataSet$MARITAL_STATUS  == 'Divoced' & dataSet$STATUS == "T")


data <- data.frame(
  category=c("Married (A)", "Single(A)","Divoced(A)"),
  count=c(M_yes_0, M_yes_1,M_yes_2)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
##################
data <- data.frame(
  category=c("Married(T)", "Single(T)","Divoced(T)"),
  count=c(M_no_0,M_no_1,M_no_2)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")


# ################ For EDUCATION STATUS  ###############################
# ##########################################################
E_yes_0 <- sum(dataSet$EDUCATION_LEVEL == 'LEVEL 1' & dataSet$STATUS  == "A")
E_yes_1 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 2' & dataSet$STATUS  == "A")
E_yes_2 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 3' & dataSet$STATUS  == "A")
E_yes_3 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 4' & dataSet$STATUS  == "A")
E_yes_4 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 5' & dataSet$STATUS  == "A")


E_no_0 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 1' & dataSet$STATUS  == "T")
E_no_1 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 2' & dataSet$STATUS == "T")
E_no_2 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 3' & dataSet$STATUS == "T")
E_no_3 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 4' & dataSet$STATUS == "T")
E_no_4 <- sum(dataSet$EDUCATION_LEVEL  == 'LEVEL 5' & dataSet$STATUS == "T")



data <- data.frame(
  category=c("LEVEL 1(A)", "LEVEL 2(A)","LEVEL 3(A)","LEVEL 4(A)","LEVEL 5(A)"),
  count=c(E_yes_0, E_yes_1,E_yes_2,E_yes_3,E_yes_4)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
##################
data <- data.frame(
  category=c("LEVEL 1(T)", "LEVEL 2(T)","LEVEL 3(T)","LEVEL 4(T)","LEVEL 5(T)"),
  count=c(E_no_0,E_no_1,E_no_2,E_no_3,E_no_4)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")


# ################ For ETHINICITY STATUS  ###############################
# ##########################################################
E_yes_0 <- sum(dataSet$ETHNICITY == 'AMIND' & dataSet$STATUS  == "A")
E_yes_1 <- sum(dataSet$ETHNICITY  == 'ASIAN' & dataSet$STATUS  == "A")
E_yes_2 <- sum(dataSet$ETHNICITY  == 'BLACK' & dataSet$STATUS  == "A")
E_yes_3 <- sum(dataSet$ETHNICITY  == 'HISPA' & dataSet$STATUS  == "A")
E_yes_4 <- sum(dataSet$ETHNICITY  == 'PACIF' & dataSet$STATUS  == "A")
E_yes_5 <- sum(dataSet$ETHNICITY  == 'TWO' & dataSet$STATUS  == "A")
E_yes_6 <- sum(dataSet$ETHNICITY  == 'WHITE' & dataSet$STATUS  == "A")


E_no_0 <- sum(dataSet$ETHNICITY  == 'AMIND' & dataSet$STATUS  == "T")
E_no_1 <- sum(dataSet$ETHNICITY  == 'ASIAN' & dataSet$STATUS == "T")
E_no_2 <- sum(dataSet$ETHNICITY  == 'BLACK' & dataSet$STATUS == "T")
E_no_3 <- sum(dataSet$ETHNICITY  == 'HISPA' & dataSet$STATUS == "T")
E_no_4 <- sum(dataSet$ETHNICITY  == 'PACIF' & dataSet$STATUS == "T")
E_no_5 <- sum(dataSet$ETHNICITY  == 'TWO' & dataSet$STATUS == "T")
E_no_6 <- sum(dataSet$ETHNICITY  == 'WHITE' & dataSet$STATUS == "T")


data <- data.frame(
  category=c("AMIND(A)", "ASIAN(A)","BLACK(A)","HISPA(A)","PACIF(A)","TWO(A)","WHITE(A)"),
  count=c(E_yes_0, E_yes_1,E_yes_2,E_yes_3,E_yes_4,E_yes_5,E_yes_6)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
##################
data <- data.frame(
  category=c("AMIND(A)", "ASIAN(A)","BLACK(A)","HISPA(A)","PACIF(A)","TWO(A)","WHITE(A)"),
  count=c(E_no_0,E_no_1,E_no_2,E_no_3,E_no_4,E_no_5,E_no_6)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")


# ################ For PERFORMANCE RATING STATUS  ###############################
# ##########################################################
P_yes_0 <- sum(dataSet$PERFORMANCE_RATING == 1 & dataSet$STATUS  == "A")
P_yes_1 <- sum(dataSet$PERFORMANCE_RATING  == 2 & dataSet$STATUS  == "A")
P_yes_2 <- sum(dataSet$PERFORMANCE_RATING  == 3 & dataSet$STATUS  == "A")
P_yes_3 <- sum(dataSet$PERFORMANCE_RATING  == 4 & dataSet$STATUS  == "A")
P_yes_4 <- sum(dataSet$PERFORMANCE_RATING  == 5 & dataSet$STATUS  == "A")


P_no_0 <- sum(dataSet$PERFORMANCE_RATING  == 1 & dataSet$STATUS  == "T")
P_no_1 <- sum(dataSet$PERFORMANCE_RATING  == 2 & dataSet$STATUS == "T")
P_no_2 <- sum(dataSet$PERFORMANCE_RATING  == 3 & dataSet$STATUS == "T")
P_no_3 <- sum(dataSet$PERFORMANCE_RATING  == 4 & dataSet$STATUS == "T")
P_no_4 <- sum(dataSet$PERFORMANCE_RATING  == 5 & dataSet$STATUS == "T")


data <- data.frame(
  category=c("PERF_RATING(1)(A)", "PERF_RATING(2)(A)","PERF_RATING(3)(A)","PERF_RATING(4)(A)","PERF_RATING(5)(A)"),
  count=c(E_yes_0, E_yes_1,E_yes_2,E_yes_3,E_yes_4)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
##################
data <- data.frame(
  category=c("PERF_RATING(1)(T)", "PERF_RATING(2)(T)","PERF_RATING(3)(T)","PERF_RATING(4)(T)","PERF_RATING(5)(T)"),
  count=c(E_no_0,E_no_1,E_no_2,E_no_3,E_no_4)
)
data$fraction <- data$count / sum(data$count)
data$ymax <- cumsum(data$fraction)
data$ymin <- c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n value: ", data$count)
# For Churn
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.23, aes(y=labelPosition, label=label), size=4) +
  scale_fill_brewer(palette=13) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")
###### Classification Algorithms ########
###### Classification Algorithms ############

###### Classification Algorithms ############
