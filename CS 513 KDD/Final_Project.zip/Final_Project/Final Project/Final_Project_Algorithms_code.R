# PROJECT TEAM: 
# KDD - FINAL PROJECT

## remove all objects
rm(list=ls())
dev.off()

#Reading data file
dataSet<- read.csv(file.choose())
str(dataSet)
#summary of the data
summary(dataSet)
str(dataSet)
# Cleaning the data and factoring the variables 
dataSet[dataSet==""]<-NA
is.na(dataSet) <- sapply(dataSet, is.infinite)  #setting infinite value to NA
dataSet[is.na(dataSet)] <- 0 #setting NA value to 0
dataSet$REFERRAL_SOURCE <- as.character(dataSet$REFERRAL_SOURCE)     # to change na values in character array
dataSet$REFERRAL_SOURCE[is.na(dataSet$REFERRAL_SOURCE)] <- "Single"  # to change na values in character array
sum(is.na(dataSet))  # to check for na values
dataSet<-na.omit(dataSet)
sum(is.na(dataSet))  # to check for na values
sum(is.nan(factor(dataSet))) # to check for nan values 
sum(is.infinite(factor(dataSet)))  #to check for infinite values

#Converting everything to factor
dataSet$JOBCODE <- factor(dataSet$JOBCODE)
dataSet$REHIRE <- as.character(dataSet$REHIRE)
dataSet$REHIRE <- as.factor(dataSet$REHIRE)
dataSet$IS_FIRST_JOB <- as.character(dataSet$IS_FIRST_JOB)
dataSet$IS_FIRST_JOB <- as.factor(dataSet$IS_FIRST_JOB)
dataSet$STATUS <- as.character(dataSet$STATUS)
dataSet$STATUS <- as.factor(dataSet$STATUS)
dataSet$ETHNICITY <- as.character(dataSet$ETHNICITY)
dataSet$ETHNICITY <- as.factor(dataSet$ETHNICITY)
dataSet$EDUCATION_LEVEL <- as.character(dataSet$EDUCATION_LEVEL)
dataSet$EDUCATION_LEVEL <- as.factor(dataSet$EDUCATION_LEVEL)
dataSet$SEX <- as.character(dataSet$SEX)
dataSet$SEX <- as.factor(dataSet$SEX)
dataSet$MARITAL_STATUS <- as.character(dataSet$MARITAL_STATUS)
dataSet$MARITAL_STATUS <- as.factor(dataSet$MARITAL_STATUS)
#Decreasing no of levels
dataSet$HRLY_RATE<-findInterval(dataSet$HRLY_RATE, c(30, 60, 90))
dataSet$HRLY_RATE <- as.factor(dataSet$HRLY_RATE)
dataSet$AGE<-findInterval(dataSet$AGE, c(20, 30, 40,50,60,64))
dataSet$AGE <- as.factor(dataSet$AGE)
dataSet$JOB_SATISFACTION <- as.factor(dataSet$JOB_SATISFACTION)
dataSet$TERMINATION_YEAR<-findInterval(dataSet$TERMINATION_YEAR, c(2008, 2011, 2017))
dataSet$TERMINATION_YEAR <- as.factor(dataSet$TERMINATION_YEAR)
dataSet$NUMBER_OF_TEAM_CHANGED<-findInterval(dataSet$NUMBER_OF_TEAM_CHANGED, c(0, 1, 2))
dataSet$NUMBER_OF_TEAM_CHANGED <- as.factor(dataSet$NUMBER_OF_TEAM_CHANGED)
dataSet$PREVYR_1 <- as.factor(dataSet$PREVYR_1)
dataSet$PREVYR_2 <- as.factor(dataSet$PREVYR_2)
dataSet$PREVYR_3 <- as.factor(dataSet$PREVYR_3)
dataSet$PREVYR_4 <- as.factor(dataSet$PREVYR_4)
dataSet$PREVYR_5 <- as.factor(dataSet$PREVYR_5)

#Setting seed value
set.seed(111)


# Removing unnecessary columns
dataSet_new <- subset(dataSet, select = -c(1,3,4,6,8,16,13,17,11,12,14,18,19,20,22))
str(dataSet_new)

# Converting to Numeric
dataSet_new$ANNUAL_RATE <- as.numeric(dataSet_new$ANNUAL_RATE)
dataSet_new$ETHNICITY <- as.numeric(dataSet_new$ETHNICITY)
dataSet_new$MARITAL_STATUS <- as.numeric(dataSet_new$MARITAL_STATUS)
dataSet_new$AGE <- as.numeric(dataSet_new$AGE)
dataSet_new$NUMBER_OF_TEAM_CHANGED <- as.numeric(dataSet_new$NUMBER_OF_TEAM_CHANGED)
dataSet_new$IS_FIRST_JOB <- as.numeric(dataSet_new$IS_FIRST_JOB)
dataSet_new$PREVYR_1 <- as.numeric(dataSet_new$PREVYR_1)
dataSet_new$PREVYR_2 <- as.numeric(dataSet_new$PREVYR_2)
dataSet_new$PREVYR_3 <- as.numeric(dataSet_new$PREVYR_3)
dataSet_new$PREVYR_4 <- as.numeric(dataSet_new$PREVYR_4)
dataSet_new$PREVYR_5 <- as.numeric(dataSet_new$PREVYR_5)

# Normalization function
mnorm<-function(x)
{z<-((x-min(x))/(max(x)-min(x)))
return (z)}

# Normalizing variables used
dataSet_new$ANNUAL_RATE <- mnorm(dataSet_new$ANNUAL_RATE)
dataSet_new$ETHNICITY <- mnorm(dataSet_new$ETHNICITY)
dataSet_new$MARITAL_STATUS <- mnorm(dataSet_new$MARITAL_STATUS)
dataSet_new$AGE <- mnorm(dataSet_new$AGE)
dataSet_new$NUMBER_OF_TEAM_CHANGED <- mnorm(dataSet_new$NUMBER_OF_TEAM_CHANGED)
dataSet_new$IS_FIRST_JOB <- mnorm(dataSet_new$IS_FIRST_JOB)
dataSet_new$PREVYR_1 <- mnorm(dataSet_new$PREVYR_1)
dataSet_new$PREVYR_2 <- mnorm(dataSet_new$PREVYR_2)
dataSet_new$PREVYR_3 <- mnorm(dataSet_new$PREVYR_3)
dataSet_new$PREVYR_4 <- mnorm(dataSet_new$PREVYR_4)
dataSet_new$PREVYR_5 <- mnorm(dataSet_new$PREVYR_5)

# To split the data set into test and testing 
idx<-sort(sample(nrow(dataSet_new),as.integer(.70*nrow(dataSet_new))))
training<-dataSet_new[idx,]
test<-dataSet_new[-idx,]

######################################## KNN ############################################
#Library used
library(kknn)
#Prediction for k = 3
predict_k3 <- kknn(formula=STATUS ~.,training,test,k=3,kernel="rectangular")
fit_3<-fitted(predict_k3)
table(ACTUAL = test$STATUS, PREDICTED = fit_3) # Confusion Matrix
table(ANNUAL_RATE = test$ANNUAL_RATE, Predicted = fit_3)

# Calculating Error
knn_wrong_3 <- sum(fit_3!=test$STATUS)
knn_error_rate_3 <- knn_wrong_3/length(fit_3)
knn_error_rate_3                              # ERROR RATE of the model with k = 3
# Calculating Accuracy
knn_accuracy_3 <- 1 - knn_error_rate_3        
knn_accuracy_3                                # ACCURACY of the model with k = 3

#Prediction for k = 5
predict_k5 <- kknn(formula=STATUS ~ .,training,test,k=5,kernel="rectangular")
fit_5<-fitted(predict_k5)
table(ACTUAL = test$STATUS, PREDICTED = fit_5) # Confusion Matrix

# Calculating Error
knn_wrong_5 <- sum(fit_5!=test$STATUS)
knn_error_rate_5 <- knn_wrong_5/length(fit_5)
knn_error_rate_5                            # ERROR RATE of the model with k = 5
knn_accuracy_5 <- 1 - knn_error_rate_5
knn_accuracy_5                              # ACCURACY of the model with k = 5

#Prediction for k = 10
predict_k10 <- kknn(formula=STATUS ~ .,training,test,k=10,kernel="rectangular")
fit_10<-fitted(predict_k10)
table(ACTUAL = test$STATUS, PREDICTED = fit_10) # Confusion Matrix

knn_wrong_10 <- sum(fit_10!=test$STATUS)
knn_error_rate_10 <- knn_wrong_10/length(fit_10)
knn_error_rate_10                            # ERROR RATE of the model with k = 10
knn_accuracy_10 <- 1 - knn_error_rate_10
knn_accuracy_10                               # ACCURACY of the model with k = 10

######################################## Naive Bayes ##################################
library(e1071)
nb <- naiveBayes(STATUS ~ ., data = training)
nb_predict <- predict(nb, test)
table(PREDICT = nb_predict, ACTUAL = test$STATUS)           # Confusion Matrix
table(PREVYR_1 = test$PREVYR_1, PREDICTION =  nb_predict)    # Table shows inference
# Calculating Error 
nb_wrong <- sum(nb_predict!=test$STATUS)
nb_error_rate <- nb_wrong/length(nb_predict)
nb_error_rate                               # ERROR RATE of the model
Accuracy_NB <- 1 - nb_error_rate
Accuracy_NB                                   # ACCURACY of the model

####################################### CART ###########################################
library(rpart)        
library(rpart.plot)   
library(rattle)     

CART_class<-rpart( STATUS~. ,data=training)
rpart.plot(CART_class)                   # Plots the TREE
CART_predict2<-predict(CART_class,test, type="class") # Classification
table(Actual=test$STATUS ,CART=CART_predict2)   # Confusion Matrix
table(ANNUAL_RATE = test$ANNUAL_RATE, PREDICTION =  CART_predict2)    # Table shows inference
# Calculating Error
CART_wrong<-sum(test$STATUS!=CART_predict2)
CART_error_rate<-CART_wrong/length(test$STATUS)
CART_error_rate                              # ERROR RATE of the model
Accuracy_CART <- 1 - CART_error_rate
Accuracy_CART                                # ACCURACY of the model
# much fancier graph
fancyRpartPlot(CART_class)

##################################### C 5.0 ##########################################

library(C50)
C50_class <- C5.0(STATUS ~.,data = training )
plot(C50_class)
C50_predict<-predict( C50_class ,test , type="class" )
table(actual=test$STATUS ,C50=C50_predict)      # Confusion Matrix
table(PREVYR_5 = test$PREVYR_5, PREDICTION =  C50_predict)    # Table shows inference

wrong<- (test$STATUS!=C50_predict)
c50_rate<-sum(wrong)/length(test$STATUS)
c50_rate                                    # ERROR RATE of the model
Accuracy_c50 <- 1 - c50_rate
Accuracy_c50                                # ACCURACY of the model

################################# RANDOM FOREST #######################################
library(randomForest)
fit <- randomForest(STATUS ~ ., data=training, importance=TRUE, ntree=500)
Prediction <- predict(fit, test)
table(Prediction, actual=test$STATUS)                         # Confusion Matrix
importance(fit)
varImpPlot(fit)
table(PREVYR_ = test$PREVYR_5, PREDICTION =  Prediction)    # Table shows inference


# Calculating Error Rate
wrong<- (test$STATUS!=Prediction )
errorRate_RF<-sum(wrong)/length(wrong)
errorRate_RF                                  # ERROR RATE of the model
# Calculating Accuracy
Accuracy_RF <- 1 - errorRate_RF
Accuracy_RF                                   # ACCURACY of the model

###################################### SVM #############################################
svm <- svm(STATUS~., data = training)
svm_predict <- predict(svm, test)
head(svm_predict)
table(ACTUAL = test$STATUS, svm_predict)
table(PREVYR_1 = test$PREVYR_1, PREDICTION =  svm_predict)    # Table shows inference

svm_wrong <- (test$STATUS!=svm_predict)
svm_error_rate <- sum(svm_wrong)/length(svm_wrong)
svm_error_rate                                 # ERROR RATE of the model

Accuracy_svm <- 1 - svm_error_rate
Accuracy_svm                                  # ACCURACY of the model

###################################### ANN ##############################################
library("neuralnet")
levels(dataSet_new$STATUS)
ann_data<-data.frame(lapply(dataSet_new,as.numeric))

idx <- seq (1,nrow(ann_data),by=5)
test<- ann_data[idx,]
training<-ann_data[-idx,]

#training_ann <- data.frame(lapply(training,as.numeric))
#test_ann <- data.frame(lapply(test,as.numeric))
net_ann<- neuralnet( STATUS ~ .,training, hidden=5, threshold=0.1)

#Plot the neural network
plot(net_ann)
prediction_ann <- predict(net_ann,test)
ann_cat<-ifelse(prediction_ann <1.5,1,2)
length(ann_cat)
table(Actual=test$STATUS,prediction=ann_cat)

# Calculating Error Rate                       
wrong<- (test$STATUS!=ann_cat)
error_rate_ann<-sum(wrong)/length(wrong)
error_rate_ann                                # ERROR RATE of the model
# Calculating Accuracy                        
accuracy_ann <- 1-error_rate_ann
accuracy_ann                                     # ACCURACY of the model

########################################### END ###########################################


